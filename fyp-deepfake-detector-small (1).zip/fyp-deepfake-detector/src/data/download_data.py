"""Dataset acquisition guide for the Deepfake Video Detector.

This script downloads NOTHING (the datasets are hundreds of GB and need a GPU
machine / Colab to be useful). Instead it prints step-by-step instructions with
the official sources, and can verify that your local ``data/`` folder follows
the layout every later script expects::

    data/
        real/   # pristine videos, e.g. 000.mp4, 001.mp4, ...
        fake/   # manipulated videos

Usage:
    python -m src.data.download_data --dataset all
    python -m src.data.download_data --check
"""

import argparse
import sys
from pathlib import Path

# Official sources. Always prefer these over third-party mirrors: deepfake
# datasets are frequently re-uploaded with wrong labels.
DATASETS = {
    "faceforensics": {
        "name": "FaceForensics++",
        "url": "https://github.com/ondyari/FaceForensics",
        "size": "~120 GB (all manipulations) — c23 split is enough to start",
        "notes": (
            "1. Follow the download instructions in the official GitHub repo "
            "(it hosts the download script and Google Drive links).\n"
            "2. You need the 'original' (real) sequences and at least one "
            "manipulation method, e.g. Deepfakes or FaceSwap.\n"
            "3. The 'c23' (light compression) version is the standard "
            "benchmark split; 'c40' is heavily compressed like WhatsApp forwards."
        ),
    },
    "celebdf": {
        "name": "Celeb-DF v2",
        "url": "https://github.com/yuezunli/celeb-deepfakeforensics",
        "size": "~70 GB",
        "notes": (
            "1. Request/download from the official repo (Google Drive links).\n"
            "2. Higher visual quality than FaceForensics++ — good second "
            "dataset for cross-dataset evaluation in your report.\n"
            "3. Comes as Celeb-real / Celeb-synthesis folders; rename to "
            "real/ and fake/ when copying into data/."
        ),
    },
}


def print_instructions(dataset_key: str) -> None:
    """Print acquisition instructions for one dataset."""
    info = DATASETS[dataset_key]
    print(f"\n=== {info['name']} ===")
    print(f"Official source : {info['url']}")
    print(f"Size            : {info['size']}")
    print("Steps           :")
    for line in info["notes"].split("\n"):
        print(f"  {line}")
    print(
        "\nAfter downloading, organise videos as:\n"
        "  data/real/<video>.mp4   <- pristine videos\n"
        "  data/fake/<video>.mp4   <- manipulated videos"
    )


def check_layout(data_root: Path) -> bool:
    """Verify data/real and data/fake exist and contain video files.

    Returns True when the layout looks usable.
    """
    ok = True
    for split in ("real", "fake"):
        split_dir = data_root / split
        if not split_dir.is_dir():
            print(f"[MISSING] {split_dir}/ does not exist")
            ok = False
            continue
        videos = [
            p for p in split_dir.iterdir()
            if p.suffix.lower() in {".mp4", ".avi", ".mov", ".mkv", ".webm"}
        ]
        print(f"[OK] {split_dir}/ : {len(videos)} video(s)")
        if not videos:
            print(f"       ^-- empty: put {split} videos here")
            ok = False
    return ok


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Print dataset download instructions / verify data layout."
    )
    parser.add_argument(
        "--dataset",
        choices=["faceforensics", "celebdf", "all"],
        default="all",
        help="which dataset instructions to print (default: all)",
    )
    parser.add_argument(
        "--data-root",
        default="data",
        help="dataset root to verify with --check (default: data)",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="only verify the local data/real + data/fake layout, print nothing else",
    )
    args = parser.parse_args(argv)

    if args.check:
        ok = check_layout(Path(args.data_root))
        return 0 if ok else 1

    keys = list(DATASETS) if args.dataset == "all" else [args.dataset]
    print("Deepfake Video Detector — dataset acquisition guide")
    print("NOTE: nothing is downloaded by this script; follow the steps below.")
    for key in keys:
        print_instructions(key)
    print("\nTip: start small — 200 real + 200 fake videos are enough to verify")
    print("the full pipeline end-to-end before scaling up on Colab.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
