"""Extract frames from videos with OpenCV.

Why a fixed low fps: deepfake artefacts (blending boundaries, flicker) persist
across neighbouring frames, so 2 fps keeps almost all the signal while cutting
compute ~12x versus full-fps processing. Inference additionally caps the frame
count so one long video cannot exhaust memory/time.

Single video:
    python -m src.data.extract_frames --video data/real/000.mp4 --out data/frames/real/000 --fps 2

Whole dataset (mirrors the input directory layout):
    python -m src.data.extract_frames --batch-dir data/videos --out-dir data/frames --fps 2

Frames are saved as ``frame_{index:06d}.jpg`` where *index* counts sampled
frames (0, 1, 2, ...), so ``timestamp_seconds = index / fps``.
"""

import argparse
import sys
from pathlib import Path

import cv2

VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".webm", ".mpg", ".mpeg"}


def extract_frames(video_path, out_dir, fps=2, max_frames=None, quality=95):
    """Sample frames from one video.

    Args:
        video_path: path to the input video.
        out_dir: directory receiving ``frame_XXXXXX.jpg`` files (created).
        fps: sampling rate in frames per second.
        max_frames: stop after this many sampled frames (None = no cap).
        quality: JPEG quality 1-100.

    Returns:
        List of ``(frame_path, timestamp_seconds)`` tuples in time order.

    Raises:
        RuntimeError: if the video cannot be opened.
    """
    video_path = Path(video_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    # Source fps may be 0 for some containers; fall back to a sane default.
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    # Read every `step`-th decoded frame to approximate the target fps.
    step = max(int(round(src_fps / fps)), 1)

    saved = []
    decoded_idx = 0
    sampled_idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if decoded_idx % step == 0:
            frame_path = out_dir / f"frame_{sampled_idx:06d}.jpg"
            cv2.imwrite(
                str(frame_path),
                frame,
                [cv2.IMWRITE_JPEG_QUALITY, int(quality)],
            )
            saved.append((frame_path, sampled_idx / fps))
            sampled_idx += 1
            if max_frames is not None and sampled_idx >= max_frames:
                break
        decoded_idx += 1
    cap.release()
    return saved


def extract_frames_batch(input_dir, out_dir, fps=2, max_frames=None, quality=95):
    """Extract frames for every video under ``input_dir``.

    The output mirrors the input layout: ``<input>/real/a.mp4`` becomes
    ``<out>/real/a/frame_XXXXXX.jpg``. Returns total sampled frames.
    """
    input_dir = Path(input_dir)
    videos = sorted(
        p for p in input_dir.rglob("*")
        if p.is_file() and p.suffix.lower() in VIDEO_EXTS
    )
    if not videos:
        raise RuntimeError(f"No videos found under {input_dir}")
    total = 0
    for video in videos:
        rel = video.relative_to(input_dir).with_suffix("")  # e.g. real/a
        dest = Path(out_dir) / rel
        saved = extract_frames(video, dest, fps=fps, max_frames=max_frames,
                               quality=quality)
        total += len(saved)
        print(f"  {video.name}: {len(saved)} frames -> {dest}")
    return total


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Extract video frames at a fixed fps (single video or batch)."
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--video", help="single input video path")
    mode.add_argument("--out", help="output frames dir (with --video)")
    mode.add_argument("--batch-dir", help="input dir of videos (batch mode)")
    parser.add_argument("--out-dir", help="output root dir (with --batch-dir)")
    parser.add_argument("--fps", type=float, default=2,
                        help="sampling fps (default: 2)")
    parser.add_argument("--max-frames", type=int, default=None,
                        help="cap sampled frames per video (default: none)")
    parser.add_argument("--quality", type=int, default=95,
                        help="JPEG quality 1-100 (default: 95)")
    args = parser.parse_args(argv)

    if args.video:
        if not args.out:
            parser.error("--out is required with --video")
        saved = extract_frames(args.video, args.out, fps=args.fps,
                               max_frames=args.max_frames, quality=args.quality)
        print(f"Saved {len(saved)} frames to {args.out}")
    else:
        if not args.out_dir:
            parser.error("--out-dir is required with --batch-dir")
        total = extract_frames_batch(args.batch_dir, args.out_dir, fps=args.fps,
                                     max_frames=args.max_frames, quality=args.quality)
        print(f"Done: {total} frames total under {args.out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
