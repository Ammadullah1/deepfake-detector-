"""Detect faces in extracted frames and save aligned 224x224 crops.

Pipeline detail: MTCNN (facenet-pytorch) finds the face box, we keep the
LARGEST face per frame (deepfake datasets are single-subject; keeping every
detection would add background false positives), expand it by a small margin,
and resize to 224x224. Frames with no detected face are skipped — a missing
face carries no fake/real signal and would only add noise.

Output: ``<out>/<video_id>/face_XXXXXX.jpg`` plus a manifest CSV with columns
``path,label,video_id,frame_idx,timestamp`` consumed by training.

Usage:
    python -m src.data.extract_faces --frames-dir data/frames \\
        --out-dir data/faces --manifest data/manifest.csv --label-from-parent
    # frames/real/<video>/... and frames/fake/<video>/... -> label from parent
"""

import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image
from tqdm import tqdm

MANIFEST_COLUMNS = ["path", "label", "video_id", "frame_idx", "timestamp"]


def load_mtcnn(device="auto", min_face_size=40):
    """Build an MTCNN face detector (import is lazy: facenet-pytorch is heavy).

    Args:
        device: "auto" (CUDA if available else CPU), "cuda" or "cpu".
        min_face_size: ignore detections smaller than this (pixels).
    """
    from facenet_pytorch import MTCNN  # lazy: keeps CLI --help fast

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    # margin=0 here: we apply our own margin in detect_largest_face so the
    # behaviour is identical for training crops and inference crops.
    return MTCNN(image_size=224, margin=0, min_face_size=min_face_size,
                 keep_all=False, device=device)


def detect_largest_face(pil_image, mtcnn, margin=20, image_size=224):
    """Return the largest detected face as a PIL crop, or None if no face.

    The crop is the detection box expanded by ``margin`` pixels on each side
    (clamped to the image) and resized to ``image_size``.
    """
    boxes, _probs = mtcnn.detect(pil_image)
    if boxes is None or len(boxes) == 0:
        return None
    # Largest box by area — robust when MTCNN fires on background patches.
    areas = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
    x1, y1, x2, y2 = boxes[int(np.argmax(areas))]
    w, h = pil_image.size
    x1 = max(0, int(x1 - margin))
    y1 = max(0, int(y1 - margin))
    x2 = min(w, int(x2 + margin))
    y2 = min(h, int(y2 + margin))
    if x2 <= x1 or y2 <= y1:
        return None
    crop = pil_image.crop((x1, y1, x2, y2))
    return crop.resize((image_size, image_size), Image.BILINEAR)


def extract_faces(frames_dir, out_dir, manifest_path, label=None,
                  label_from_parent=False, fps=2, device="auto"):
    """Crop faces from all frames under ``frames_dir`` and write the manifest.

    Args:
        frames_dir: root containing frame JPEGs (any nesting depth).
        out_dir: destination root for face crops.
        manifest_path: CSV path to write (parent dirs created).
        label: single label ("real"/"fake") applied to every frame.
        label_from_parent: take the label from the video dir's parent name,
            i.e. ``frames/<label>/<video_id>/frame_*.jpg``.
        fps: sampling fps used during frame extraction (for timestamps).
        device: passed to :func:`load_mtcnn`.

    Returns:
        ``(kept, skipped)`` counts.
    """
    if label is None and not label_from_parent:
        raise ValueError("Provide --label or --label-from-parent")
    if label is not None and label not in ("real", "fake"):
        raise ValueError("label must be 'real' or 'fake'")

    mtcnn = load_mtcnn(device=device)
    out_dir = Path(out_dir)
    frame_files = sorted(Path(frames_dir).rglob("*.jpg"))
    if not frame_files:
        raise RuntimeError(f"No frame JPEGs found under {frames_dir}")

    rows = []
    kept, skipped = 0, 0
    for frame_path in tqdm(frame_files, desc="Cropping faces"):
        video_id = frame_path.parent.name
        lbl = frame_path.parent.parent.name if label_from_parent else label
        match = re.search(r"(\d+)", frame_path.stem)
        frame_idx = int(match.group(1)) if match else 0
        timestamp = frame_idx / fps

        pil_image = Image.open(frame_path).convert("RGB")
        crop = detect_largest_face(pil_image, mtcnn, margin=20, image_size=224)
        if crop is None:
            skipped += 1
            continue

        dest = out_dir / video_id / f"face_{frame_idx:06d}.jpg"
        dest.parent.mkdir(parents=True, exist_ok=True)
        crop.save(dest, quality=95)
        rows.append({
            "path": dest.as_posix(),   # repo-root-relative, e.g. data/faces/...
            "label": lbl,
            "video_id": video_id,
            "frame_idx": frame_idx,
            "timestamp": round(timestamp, 2),
        })
        kept += 1

    manifest_path = Path(manifest_path)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows, columns=MANIFEST_COLUMNS).to_csv(manifest_path, index=False)
    return kept, skipped


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Detect faces in frames and build the training manifest CSV."
    )
    parser.add_argument("--frames-dir", required=True,
                        help="root dir of extracted frame JPEGs")
    parser.add_argument("--out-dir", required=True,
                        help="destination root for 224x224 face crops")
    parser.add_argument("--manifest", required=True,
                        help="output manifest CSV path")
    parser.add_argument("--label", choices=["real", "fake"], default=None,
                        help="single label for all frames")
    parser.add_argument("--label-from-parent", action="store_true",
                        help="take label from the video dir's parent name "
                             "(frames/<label>/<video_id>/*.jpg)")
    parser.add_argument("--fps", type=float, default=2,
                        help="fps used in frame extraction (default: 2)")
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"],
                        help="MTCNN device (default: auto)")
    args = parser.parse_args(argv)

    kept, skipped = extract_faces(
        args.frames_dir, args.out_dir, args.manifest,
        label=args.label, label_from_parent=args.label_from_parent,
        fps=args.fps, device=args.device,
    )
    print(f"Done: {kept} face crops kept, {skipped} frames skipped (no face).")
    print(f"Manifest: {args.manifest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
