"""Data preparation: dataset download guide, frame extraction, face extraction."""
