"""CNN classifier for deepfake face-crop classification.

Design: EfficientNet-B0 backbone with ImageNet-pretrained weights, classifier
head replaced by ``Dropout(0.3) -> Linear(1280, 1)`` producing a single logit.

Why this shape:
- B0 is the smallest EfficientNet: it trains in reasonable time on a free
  Colab GPU while ImageNet pretraining transfers well to face forensics
  (the FaceForensics++ baselines use the same family).
- One logit + BCEWithLogitsLoss is the numerically stable standard for
  binary classification (no separate sigmoid layer to saturate).
- Dropout 0.3 regularises the head because face-crop datasets are small
  relative to the backbone's capacity.
"""

import torch.nn as nn
from torchvision import models


class DeepfakeDetector(nn.Module):
    """Binary deepfake classifier.

    ``forward(x)`` returns raw logits of shape ``(N, 1)``; apply
    ``torch.sigmoid`` to obtain fake probabilities in [0, 1].
    """

    def __init__(self, backbone="efficientnet_b0", pretrained=True, dropout=0.3):
        super().__init__()
        if backbone != "efficientnet_b0":
            raise ValueError(f"Unsupported backbone: {backbone!r} "
                             "(only 'efficientnet_b0' is implemented)")
        weights = (models.EfficientNet_B0_Weights.IMAGENET1K_V1
                   if pretrained else None)
        self.backbone = models.efficientnet_b0(weights=weights)

        in_features = self.backbone.classifier[1].in_features  # 1280 for B0
        self.backbone.classifier = nn.Sequential(
            nn.Dropout(p=dropout, inplace=True),
            nn.Linear(in_features, 1),
        )

    def forward(self, x):
        return self.backbone(x)

    def count_parameters(self):
        """Number of trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def create_model(backbone="efficientnet_b0", pretrained=True, dropout=0.3):
    """Factory used by training and inference so both share one definition."""
    return DeepfakeDetector(backbone=backbone, pretrained=pretrained,
                            dropout=dropout)
