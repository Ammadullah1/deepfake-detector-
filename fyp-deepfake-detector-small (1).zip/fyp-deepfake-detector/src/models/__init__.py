"""Model architectures for deepfake classification."""

from src.models.detector import DeepfakeDetector, create_model

__all__ = ["DeepfakeDetector", "create_model"]
