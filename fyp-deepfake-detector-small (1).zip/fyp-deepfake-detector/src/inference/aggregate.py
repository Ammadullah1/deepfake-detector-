"""Temporal aggregation: per-frame fake probabilities -> video verdict.

Why "mean of top-50%" instead of a plain mean: in a real video every frame is
real and in a fake video only *some* frames show strong artefacts; averaging
all frames dilutes the signal of the most suspicious ones. Averaging the top
half focuses the verdict on the frames the model is most confident about,
which is the standard trick in frame-based deepfake detectors.
"""

import math


def aggregate_scores(scores, timestamps, fake_threshold=0.5,
                     suspicious_threshold=0.7):
    """Aggregate per-frame fake probabilities into a video-level verdict.

    Args:
        scores: list of per-frame fake probabilities in [0, 1], time order.
        timestamps: list of per-frame timestamps in seconds (same order).
        fake_threshold: video_score >= this -> "FAKE", else "REAL".
        suspicious_threshold: frames scoring above this form suspicious segments.

    Returns:
        Dict with ``video_score``, ``verdict``, ``confidence`` (probability of
        the predicted class), ``frames_analyzed`` and ``suspicious_segments``
        (contiguous runs above ``suspicious_threshold`` as
        ``{"start", "end", "max_score"}`` second-ranges).
    """
    scores = [float(s) for s in scores]
    timestamps = [float(t) for t in timestamps]
    if not scores:
        raise ValueError("aggregate_scores received no frame scores")
    if len(scores) != len(timestamps):
        raise ValueError("scores and timestamps length mismatch")

    # Video score = mean of the top 50% most suspicious frame scores.
    k = max(1, math.ceil(len(scores) * 0.5))
    top = sorted(scores, reverse=True)[:k]
    video_score = sum(top) / len(top)

    verdict = "FAKE" if video_score >= fake_threshold else "REAL"
    confidence = video_score if verdict == "FAKE" else 1.0 - video_score

    # Suspicious segments: contiguous runs of frames above the threshold.
    segments = []
    run_start = None
    for i, s in enumerate(scores):
        if s > suspicious_threshold and run_start is None:
            run_start = i
        elif s <= suspicious_threshold and run_start is not None:
            segments.append((run_start, i - 1))
            run_start = None
    if run_start is not None:
        segments.append((run_start, len(scores) - 1))

    seg_dicts = [
        {
            "start": round(timestamps[a], 2),
            "end": round(timestamps[b], 2),
            "max_score": round(max(scores[a:b + 1]), 3),
        }
        for a, b in segments
    ]

    return {
        "video_score": round(video_score, 4),
        "verdict": verdict,
        "confidence": round(confidence, 4),
        "frames_analyzed": len(scores),
        "suspicious_segments": seg_dicts,
    }
