"""Inference: per-frame scoring, temporal aggregation, video verdict."""
