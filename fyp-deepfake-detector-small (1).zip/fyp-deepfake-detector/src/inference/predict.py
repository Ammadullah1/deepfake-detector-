"""Video-level deepfake prediction.

Pipeline: video -> frames (2 fps, max 60) -> MTCNN face crops -> EfficientNet-B0
per-frame fake probabilities -> temporal aggregation -> verdict JSON.

The module exposes :func:`load_pipeline` (load weights + MTCNN once) and
:func:`predict_video` (run end-to-end; accepts a preloaded pipeline so the API
can reuse it across requests). The CLI is a thin wrapper around both.

Usage:
    python -m src.inference.predict --video samples/clip.mp4
    python -m src.inference.predict --video samples/clip.mp4 --out result.json
"""

import argparse
import json
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch
import yaml
from PIL import Image
from torchvision import transforms
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.data.extract_faces import detect_largest_face, load_mtcnn
from src.data.extract_frames import extract_frames
from src.inference.aggregate import aggregate_scores
from src.models.detector import create_model
from src.training.dataset import IMAGENET_MEAN, IMAGENET_STD  # same normalisation

MODEL_NOT_TRAINED_MSG = (
    "No trained model found at '{path}'. Train a model first "
    "(see README 'Train the model' / notebooks/train_on_colab.ipynb), then "
    "copy best.pt to checkpoints/ and retry."
)


def _infer_transform():
    """Deterministic preprocessing identical to validation transforms."""
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


def load_pipeline(config_path="configs/config.yaml", model_path=None,
                  device="auto"):
    """Load config, model weights and MTCNN once; returns a pipeline dict.

    Raises:
        FileNotFoundError: with a human-readable message when the checkpoint
            is missing (the API converts this into a 503 "train first" error).
    """
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    if model_path is None:
        model_path = cfg["paths"]["best_model"]
    model_path = Path(model_path)
    if not model_path.is_file():
        raise FileNotFoundError(MODEL_NOT_TRAINED_MSG.format(path=model_path))

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(device)

    mcfg = cfg["model"]
    ckpt = torch.load(model_path, map_location=device)
    # Checkpoint saved with pretrained=True; weights file carries the head, so
    # we build the same architecture and only load the state dict.
    model = create_model(backbone=mcfg["backbone"], pretrained=False,
                         dropout=mcfg["dropout"])
    model.load_state_dict(ckpt["state_dict"])
    model.to(device).eval()

    mtcnn = load_mtcnn(device=device,
                       min_face_size=cfg["faces"]["min_face_size"])
    return {
        "config": cfg,
        "device": device,
        "model": model,
        "mtcnn": mtcnn,
        "transform": _infer_transform(),
    }


def predict_video(video_path, pipeline=None, config_path="configs/config.yaml",
                  model_path=None, device="auto", show_progress=False):
    """Run the full pipeline on one video; returns a JSON-serialisable dict.

    Result keys: ``verdict`` ("FAKE"/"REAL"/"NO_FACE_DETECTED"), ``confidence``,
    ``video_score``, ``frames_analyzed``, ``suspicious_segments``,
    ``frame_scores`` and ``frame_timestamps`` (for the UI chart).
    """
    if pipeline is None:
        pipeline = load_pipeline(config_path=config_path,
                                 model_path=model_path, device=device)
    cfg = pipeline["config"]
    icfg = cfg["inference"]
    model, mtcnn = pipeline["model"], pipeline["mtcnn"]
    transform, dev = pipeline["transform"], pipeline["device"]

    with tempfile.TemporaryDirectory(prefix="dfd_frames_") as tmpdir:
        frames = extract_frames(video_path, tmpdir, fps=icfg["fps"],
                                max_frames=icfg["max_frames"],
                                quality=cfg["frames"]["jpeg_quality"])
        tensors, timestamps = [], []
        iterator = tqdm(frames, desc="faces") if show_progress else frames
        for frame_path, ts in iterator:
            pil_image = Image.open(frame_path).convert("RGB")
            crop = detect_largest_face(pil_image, mtcnn,
                                       margin=cfg["faces"]["margin"],
                                       image_size=cfg["faces"]["image_size"])
            if crop is None:
                continue  # no face: carries no signal, skip quietly
            tensors.append(transform(crop))
            timestamps.append(ts)

    if not tensors:
        return {
            "verdict": "NO_FACE_DETECTED",
            "confidence": 0.0,
            "video_score": 0.0,
            "frames_analyzed": 0,
            "suspicious_segments": [],
            "frame_scores": [],
            "frame_timestamps": [],
            "note": ("No faces were detected in the sampled frames, so no "
                     "verdict could be produced. Try a video with a visible, "
                     "front-facing person."),
        }

    batch = torch.stack(tensors).to(dev)
    with torch.no_grad():
        scores = torch.sigmoid(model(batch)).cpu().view(-1).tolist()

    agg = aggregate_scores(scores, timestamps,
                           fake_threshold=icfg["fake_threshold"],
                           suspicious_threshold=icfg["suspicious_threshold"])
    agg["frame_scores"] = [round(float(s), 3) for s in scores]
    agg["frame_timestamps"] = [round(float(t), 2) for t in timestamps]
    return agg


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Detect deepfakes: video in, verdict JSON out.")
    parser.add_argument("--video", required=True, help="input video path")
    parser.add_argument("--config", default="configs/config.yaml",
                        help="config YAML path")
    parser.add_argument("--model", default=None,
                        help="checkpoint path (default: from config)")
    parser.add_argument("--device", default="auto",
                        choices=["auto", "cuda", "cpu"],
                        help="inference device (default: auto)")
    parser.add_argument("--out", default=None,
                        help="write result JSON to this path (else stdout)")
    parser.add_argument("--progress", action="store_true",
                        help="show progress bars")
    args = parser.parse_args(argv)

    try:
        result = predict_video(args.video, config_path=args.config,
                               model_path=args.model, device=args.device,
                               show_progress=args.progress)
    except FileNotFoundError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    text = json.dumps(result, indent=2)
    if args.out:
        Path(args.out).write_text(text)
        print(f"Wrote {args.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
