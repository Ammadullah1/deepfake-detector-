"""Deepfake Video Detector — source package.

Subpackages:
    data      video/frame/face preprocessing scripts
    models    neural network architectures
    training  dataset + training loop
    inference temporal aggregation + video-level prediction
    api       FastAPI demo service
"""
