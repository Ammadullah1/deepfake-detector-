"""PyTorch dataset over the face-crop manifest CSV.

Critical detail: the train/validation split is done by VIDEO, never by frame.
Frames from one video look almost identical, so a random frame-level split
would leak near-duplicates into validation and report an inflated score —
the classic mistake in deepfake papers' reproductions.

Manifest columns: ``path,label,video_id,frame_idx,timestamp`` with
``label`` in {"real", "fake"}.
"""

import random
from pathlib import Path

import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

LABEL_MAP = {"real": 0, "fake": 1}

# ImageNet statistics: the backbone was pretrained with these, so inputs must
# be normalised identically or transfer learning degrades.
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def train_transforms():
    """Augmentations for training: flips, colour jitter, small rotations.

    These mimic compression artefacts, lighting and pose changes, which is
    exactly the variation a detector must be robust to (e.g. WhatsApp-forwarded
    clips). Applied on PIL images before tensor conversion.
    """
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ColorJitter(brightness=0.2, contrast=0.2,
                               saturation=0.2, hue=0.05),
        transforms.RandomRotation(degrees=10),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


def val_transforms():
    """Deterministic preprocessing for validation/inference."""
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


class FaceManifestDataset(Dataset):
    """Loads face crops listed in a manifest dataframe."""

    def __init__(self, dataframe, root, transform):
        self.df = dataframe.reset_index(drop=True)
        self.root = Path(root)
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        image = Image.open(self.root / row["path"]).convert("RGB")
        label = torch.tensor(float(LABEL_MAP[str(row["label"]).strip().lower()]))
        return self.transform(image), label


def train_val_split_by_video(manifest_path, val_split=0.2, seed=42):
    """Split manifest rows into train/val by video id (stratified-ish).

    Videos are shuffled with ``seed`` and dealt so each split keeps whole
    videos; label balance is approximately preserved because deepfake
    datasets ship balanced real/fake video counts.

    Returns:
        (train_df, val_df) pandas DataFrames.
    """
    df = pd.read_csv(manifest_path)
    if df.empty:
        raise RuntimeError(f"Manifest is empty: {manifest_path}")
    video_ids = sorted(df["video_id"].unique())
    rng = random.Random(seed)
    rng.shuffle(video_ids)
    n_val = max(1, int(round(len(video_ids) * val_split)))
    val_ids = set(video_ids[:n_val])
    train_df = df[~df["video_id"].isin(val_ids)].reset_index(drop=True)
    val_df = df[df["video_id"].isin(val_ids)].reset_index(drop=True)
    return train_df, val_df


def make_dataloaders(manifest_path, batch_size=32, val_split=0.2,
                     num_workers=2, seed=42, root="."):
    """Build train/val DataLoaders from a manifest CSV.

    Args:
        manifest_path: path to manifest.csv.
        root: repo root that ``path`` column values are relative to.
    """
    train_df, val_df = train_val_split_by_video(manifest_path, val_split, seed)
    print(f"Train: {len(train_df)} crops from "
          f"{train_df['video_id'].nunique()} videos | "
          f"Val: {len(val_df)} crops from {val_df['video_id'].nunique()} videos")

    train_ds = FaceManifestDataset(train_df, root, train_transforms())
    val_ds = FaceManifestDataset(val_df, root, val_transforms())

    # Seeded generator makes shuffling reproducible across runs.
    generator = torch.Generator()
    generator.manual_seed(seed)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, generator=generator)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False,
                            num_workers=num_workers)
    return train_loader, val_loader
