"""Training: manifest dataset, dataloaders, training loop."""
