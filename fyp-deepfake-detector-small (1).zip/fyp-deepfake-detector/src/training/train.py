"""Train the deepfake detector (config-driven).

Loop: AdamW + cosine LR schedule + BCEWithLogitsLoss, mixed precision on CUDA,
per-epoch validation (accuracy/precision/recall/F1/AUC), checkpointing of the
best model by validation F1, early stopping on validation loss, and finally a
confusion-matrix plot plus metrics.json.

Works on CPU too (slow but functional); CUDA is used automatically when
available. Intended to run on Google Colab — see notebooks/train_on_colab.ipynb.

Usage:
    python -m src.training.train --config configs/config.yaml
    python -m src.training.train --config configs/config.yaml --epochs 10 --batch-size 16
"""

import argparse
import json
import random
import sys
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless: Colab / servers have no display
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import yaml
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.models.detector import create_model
from src.training.dataset import make_dataloaders


def set_seed(seed: int) -> None:
    """Seed Python, NumPy and PyTorch for reproducible runs."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(pref: str) -> torch.device:
    """'auto' -> CUDA when available else CPU; explicit names honoured."""
    if pref == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(pref)


def train_one_epoch(model, loader, criterion, optimizer, scaler, device,
                    use_amp):
    """Run one training epoch; returns mean loss."""
    model.train()
    running = 0.0
    for images, labels in tqdm(loader, desc="train", leave=False):
        images = images.to(device, non_blocking=True)
        # BCEWithLogitsLoss expects (N,1) float targets.
        labels = labels.to(device, non_blocking=True).view(-1, 1)
        optimizer.zero_grad(set_to_none=True)
        # Mixed precision only on CUDA; on CPU autocast is a no-op guard.
        with torch.amp.autocast("cuda", enabled=use_amp):
            logits = model(images)
            loss = criterion(logits, labels)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        running += loss.item() * images.size(0)
    return running / len(loader.dataset)


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    """Evaluate on validation set; returns metrics dict + raw predictions."""
    model.eval()
    total_loss, y_true, y_prob = 0.0, [], []
    for images, labels in tqdm(loader, desc="val", leave=False):
        images = images.to(device, non_blocking=True)
        targets = labels.to(device, non_blocking=True).view(-1, 1)
        logits = model(images)
        total_loss += criterion(logits, targets).item() * images.size(0)
        y_true.extend(labels.tolist())
        y_prob.extend(torch.sigmoid(logits).cpu().view(-1).tolist())
    y_pred = [1 if p >= 0.5 else 0 for p in y_prob]
    y_true_i = [int(t) for t in y_true]
    metrics = {
        "loss": total_loss / len(loader.dataset),
        "accuracy": accuracy_score(y_true_i, y_pred),
        "precision": precision_score(y_true_i, y_pred, zero_division=0),
        "recall": recall_score(y_true_i, y_pred, zero_division=0),
        "f1": f1_score(y_true_i, y_pred, zero_division=0),
    }
    # AUC is undefined when a split contains a single class; guard it.
    try:
        metrics["auc"] = roc_auc_score(y_true_i, y_prob)
    except ValueError:
        metrics["auc"] = float("nan")
    return metrics, y_true_i, y_prob


def plot_confusion_matrix(y_true, y_prob, out_path):
    """Save a confusion-matrix heatmap for the validation predictions."""
    y_pred = [1 if p >= 0.5 else 0 for p in y_prob]
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1])
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["real", "fake"])
    ax.set_yticklabels(["real", "fake"])
    ax.set_xlabel("predicted")
    ax.set_ylabel("true")
    ax.set_title("Validation confusion matrix")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Train the EfficientNet-B0 deepfake detector.")
    parser.add_argument("--config", default="configs/config.yaml",
                        help="config YAML path (default: configs/config.yaml)")
    parser.add_argument("--manifest", default=None,
                        help="override manifest CSV path from config")
    parser.add_argument("--epochs", type=int, default=None,
                        help="override training epochs")
    parser.add_argument("--batch-size", type=int, default=None,
                        help="override batch size")
    parser.add_argument("--lr", type=float, default=None,
                        help="override learning rate")
    parser.add_argument("--output-dir", default=None,
                        help="override checkpoint directory")
    args = parser.parse_args(argv)

    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    tcfg = cfg["training"]
    epochs = args.epochs or tcfg["epochs"]
    batch_size = args.batch_size or tcfg["batch_size"]
    lr = args.lr or tcfg["lr"]
    manifest = args.manifest or cfg["paths"]["manifest"]
    ckpt_dir = Path(args.output_dir or cfg["paths"]["checkpoint_dir"])
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    set_seed(cfg["project"]["seed"])
    device = resolve_device(tcfg["device"])
    print(f"Device: {device}")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True  # fixed input size -> faster convs

    train_loader, val_loader = make_dataloaders(
        manifest, batch_size=batch_size, val_split=tcfg["val_split"],
        num_workers=tcfg["num_workers"], seed=cfg["project"]["seed"], root=".")

    mcfg = cfg["model"]
    model = create_model(backbone=mcfg["backbone"],
                         pretrained=mcfg["pretrained"],
                         dropout=mcfg["dropout"]).to(device)
    print(f"Model: {mcfg['backbone']} "
          f"({model.count_parameters():,} trainable params)")

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr,
                                  weight_decay=tcfg["weight_decay"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    use_amp = bool(tcfg["amp"]) and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    print(f"Mixed precision (AMP): {'on' if use_amp else 'off'}")

    best_f1, best_state, patience_left = -1.0, None, tcfg["early_stopping_patience"]
    best_val_loss = float("inf")
    history = []
    start = time.time()

    for epoch in range(1, epochs + 1):
        train_loss = train_one_epoch(model, train_loader, criterion,
                                     optimizer, scaler, device, use_amp)
        val_metrics, _, _ = evaluate(model, val_loader, criterion, device)
        scheduler.step()
        current_lr = optimizer.param_groups[0]["lr"]

        row = {"epoch": epoch, "train_loss": train_loss,
               "lr": current_lr, **{f"val_{k}": v for k, v in val_metrics.items()}}
        history.append(row)
        print(f"epoch {epoch:02d}/{epochs} "
              f"train_loss={train_loss:.4f} val_loss={val_metrics['loss']:.4f} "
              f"val_acc={val_metrics['accuracy']:.4f} val_f1={val_metrics['f1']:.4f} "
              f"val_auc={val_metrics['auc']:.4f} lr={current_lr:.2e}")

        # Checkpoint the best model by validation F1 (robust to imbalance).
        if val_metrics["f1"] > best_f1:
            best_f1 = val_metrics["f1"]
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}

        # Early stopping watches validation loss (a smoother signal than F1).
        if val_metrics["loss"] < best_val_loss - 1e-4:
            best_val_loss = val_metrics["loss"]
            patience_left = tcfg["early_stopping_patience"]
        else:
            patience_left -= 1
            if patience_left <= 0:
                print(f"Early stopping at epoch {epoch} "
                      f"(no val-loss improvement for "
                      f"{tcfg['early_stopping_patience']} epochs)")
                break

    # --- persist artefacts ---
    best_path = ckpt_dir / "best.pt"
    torch.save({
        "state_dict": best_state if best_state is not None else model.state_dict(),
        "config": {"backbone": mcfg["backbone"], "dropout": mcfg["dropout"]},
        "epochs_run": len(history),
        "best_val_f1": best_f1,
    }, best_path)

    # Recompute validation predictions with the BEST weights for the report.
    model.load_state_dict(torch.load(best_path, map_location=device)["state_dict"])
    best_metrics, y_true, y_prob = evaluate(model, val_loader, criterion, device)
    plot_confusion_matrix(y_true, y_prob, ckpt_dir / "confusion_matrix.png")

    metrics = {
        "seconds": round(time.time() - start, 1),
        "device": str(device),
        "history": history,
        "best": {"epoch": "best-by-val-f1", **best_metrics},
    }
    with open(ckpt_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nDone in {metrics['seconds']}s. Best val F1: {best_f1:.4f}")
    print(f"  model   : {best_path}")
    print(f"  metrics : {ckpt_dir / 'metrics.json'}")
    print(f"  confmat : {ckpt_dir / 'confusion_matrix.png'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
