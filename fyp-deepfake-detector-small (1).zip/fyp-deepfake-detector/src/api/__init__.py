"""Demo API: FastAPI service exposing /predict and /health."""
