"""FastAPI demo service for the Deepfake Video Detector.

Endpoints:
    GET  /health    service status + whether a trained model is loaded
    POST /predict   multipart video upload (max 50 MB) -> verdict JSON
    GET  /          static demo UI (src/frontend/index.html)

The trained model is loaded LAZILY on the first /predict request, not at
startup, so `GET /health` stays instant and the service can boot on machines
where training has not run yet. When no checkpoint exists, /predict answers
503 with a clear "train first" message instead of a stack trace.

Run from the repo root:
    uvicorn src.api.main:app --host 127.0.0.1 --port 8000
"""

import sys
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.inference.predict import load_pipeline, predict_video

ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / "configs" / "config.yaml"
FRONTEND_DIR = ROOT / "src" / "frontend"
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
ALLOWED_SUFFIXES = {".mp4", ".avi", ".mov", ".mkv", ".webm"}

app = FastAPI(
    title="Deepfake Video Detector",
    version="1.0.0",
    description="Upload a video; receive a FAKE/REAL verdict with confidence, "
                "per-frame scores and suspicious segments.",
)

# Lazily initialised on first /predict call (see module docstring).
_pipeline = None
_pipeline_error = None


def get_pipeline():
    """Return the loaded pipeline, loading it on first use.

    Raises:
        HTTPException 503: when no trained checkpoint exists yet.
    """
    global _pipeline, _pipeline_error
    if _pipeline is None and _pipeline_error is None:
        try:
            _pipeline = load_pipeline(config_path=str(CONFIG_PATH))
        except FileNotFoundError as exc:
            _pipeline_error = str(exc)
        except Exception as exc:  # corrupt checkpoint, missing weights, ...
            _pipeline_error = f"Model file exists but failed to load: {exc}"
    if _pipeline_error is not None:
        raise HTTPException(
            status_code=503,
            detail=(
                "No trained model is available. " + _pipeline_error +
                " Train a model first (README section 'Train the model', or "
                "notebooks/train_on_colab.ipynb), place best.pt at "
                "checkpoints/best.pt, then retry."
            ),
        )
    return _pipeline


@app.get("/health")
def health():
    """Liveness probe. Never triggers model loading (stays instant)."""
    return {
        "status": "ok",
        "model_loaded": _pipeline is not None,
        "device": str(_pipeline["device"]) if _pipeline is not None else None,
    }


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    """Classify an uploaded video. Returns the verdict JSON (see README)."""
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_SUFFIXES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type {suffix!r}; "
                   f"allowed: {sorted(ALLOWED_SUFFIXES)}",
        )

    # Stream the upload with a hard cap instead of trusting Content-Length,
    # which clients can lie about.
    data = bytearray()
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        data += chunk
        if len(data) > MAX_UPLOAD_BYTES:
            raise HTTPException(
                status_code=413,
                detail=f"Video exceeds the {MAX_UPLOAD_BYTES // (1024*1024)} MB limit.",
            )
    if not data:
        raise HTTPException(status_code=400, detail="Empty file uploaded.")

    pipeline = get_pipeline()  # 503 here when the model was never trained

    with tempfile.TemporaryDirectory(prefix="dfd_api_") as tmpdir:
        video_path = Path(tmpdir) / f"upload{suffix}"
        video_path.write_bytes(data)
        try:
            result = predict_video(str(video_path), pipeline=pipeline)
        except RuntimeError as exc:
            # e.g. corrupt/unreadable video container
            raise HTTPException(status_code=422,
                                detail=f"Could not process video: {exc}")
    return JSONResponse(result)


# Demo UI last: Starlette matches routes in definition order, so /health and
# /predict (defined above) win over the static mount.
app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True),
          name="frontend")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("src.api.main:app", host="127.0.0.1", port=8000, reload=False)
