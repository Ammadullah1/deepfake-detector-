# Deploy the demo as a website — no terminal needed

This puts your Deepfake Video Detector on a public link using
**Hugging Face Spaces** (free). Everything below happens in the browser —
no terminal, no `pip`, no git.

You will use **`app_pretrained.py`** (new): it downloads the public
pretrained classifier (`king1oo1/deepfake-model`, Apache 2.0) by itself on
first run, so there is **nothing to train and no 355 MB file to download
by hand**. The old `app.py` is for the self-trained track (after you train
on Colab) — it stays in the folder untouched.

## Step 1 — Create a free Hugging Face account (2 min)

1. Open https://huggingface.co/join in your browser.
2. Sign up with your email (or "Continue with Google").
3. Verify your email via the link they send.

## Step 2 — Create a new Space (2 min)

1. Click your profile picture (top-right) → **New Space**.
   (Or open https://huggingface.co/new-space directly.)
2. Fill in:
   - **Owner:** your username
   - **Space name:** `deepfake-detector`
   - **License:** `apache-2.0`
   - **Select the Space SDK:** `Gradio`
   - **Space hardware:** `CPU basic` (free)
   - **Visibility:** `Public`
3. Click **Create Space**.

## Step 3 — Upload the project files (5 min)

1. In your new Space, open the **Files** tab.
2. Click **Add file → Upload files**.
3. Drag in **everything from the 1.7 MB project zip** you downloaded
   (`app_pretrained.py`, `pretrained_demo.py`, `requirements.txt`,
   the `src/`, `configs/`, `samples/`, `docs/`, `notebooks/` folders).
   - The Space installs `requirements.txt` automatically — you do nothing.
   - The `samples/` folder gives you the two test videos as clickable examples.
4. Click **Commit changes**.

## Step 4 — Point the Space at the right app file (1 min)

Spaces runs the file named **`app.py`**. Right now the folder has two:

1. In the **Files** tab, find `app.py` (the old self-trained one) →
   click the **⋮** menu → **Rename** → `app_selftrained.py` → commit.
2. Find `app_pretrained.py` → **⋮** → **Rename** → `app.py` → commit.

## Step 5 — Wait for the build, then test (10–15 min, unattended)

1. The Space status shows **Building** while it installs everything.
   When it turns **Running**, open the **App** tab.
2. Click one of the two example videos (or upload your own short MP4).
3. The **first** detection takes a few minutes: the Space downloads the
   public model (~370 MB) and the face-detector weights once, then caches
   them. Later runs are faster.

## Step 6 — Share your link

Your demo now lives at:

```
https://huggingface.co/spaces/<your-username>/deepfake-detector
```

That link is what you show in the viva / presentation — it works on any
device with a browser, including your phone.

## Good to know

- **Free limits:** CPU-basic Spaces sleep after inactivity and wake on
  visit; the first visit after sleep is slow. Fine for a demo, not for
  24/7 production — and a demo is all the FYP needs.
- **Honesty (for the viva):** the app's page already states that the
  classifier is a public pretrained model and your original work is the
  video pipeline + aggregation. The two example videos are smoke tests,
  not a benchmark — same as `docs/PRETRAINED_MODEL.md`.
- **After Colab training (optional, later):** train the EfficientNet model
  with `notebooks/train_on_colab.ipynb`, upload the resulting
  `checkpoints/best.pt` via Files → Add file, and rename things back so
  the self-trained `app_selftrained.py` becomes `app.py`.
