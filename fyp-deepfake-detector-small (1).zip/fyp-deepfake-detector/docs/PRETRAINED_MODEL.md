# Pretrained Classifier — Honest Documentation

## What this is

The file `pretrained_demo.py` provides a **working demo with zero training**.
It pairs this FYP's own video pipeline with a publicly available pretrained
deepfake image classifier:

- **Model:** `king1oo1/deepfake-model` (Hugging Face Hub)
- **Architecture:** SigLIP2 vision transformer, image-classification head
  (2 classes: Real / Fake), 224×224 input
- **Training (by the model author, not us):** ~40,000 real/fake face images
  sampled from Deepfake-and-Real-Images, HardFake-vs-RealFaces, GRAVEX-200K,
  DeepDetect-2025 and SUT-Project sources
- **License:** Apache 2.0 (free for academic use; keep the attribution)
- **Files shipped here:** `models/pretrained/siglip2-deepfake/`
  (`model.safetensors` ≈ 355 MB, `config.json`, `preprocessor_config.json`)

## What WE built (this FYP)

Everything around the classifier is original work in this repository:

1. **Frame sampling** — 2 fps, max 60 frames (`pretrained_demo.py`)
2. **Face extraction** — MTCNN face detection, largest face per frame,
   manual PIL crop (note: facenet-pytorch's default MTCNN tensor output is
   pixel-standardized, which corrupts classifier input — we crop manually)
3. **Temporal aggregation** — video score = mean of top-50% frame scores;
   verdict FAKE if ≥ 0.5; suspicious segments = contiguous runs > 0.7
4. **Demo script / API / UI** — `pretrained_demo.py`, `src/api/main.py`,
   `src/frontend/index.html`

## Measured test results (real runs, CPU, 2026-10-19)

| Test video | Content | Verdict | Confidence | Video score | Frames |
|---|---|---|---|---|---|
| `samples/test_real.mp4` | 12 s clip, "Lena" standard test photo (definitely real) | **REAL** | 78.68% | 0.2132 | 24 |
| `samples/test_fake.mp4` | 8 s clip, 2 pravatar.cc avatars the classifier flags as synthetic | **FAKE** | 69.88% | 0.6988 | 16 |

Per-frame scores on the real video stayed 0.11–0.21 (correctly low);
on the fake video they stayed 0.58–0.93 (correctly high).

## Limitations — read before the viva

- **No accuracy claims.** These are two single-video smoke tests, not a
  benchmark. Never report an "accuracy %" for this demo.
- **Test data is thin.** `test_fake.mp4` uses avatars *believed* to be
  AI-generated (pravatar.cc serves AI avatars); it is not a certified
  deepfake. Proper fake-side evaluation needs FaceForensics++/Celeb-DF
  samples (see `src/data/download_data.py`).
- **Input sensitivity.** The classifier is sensitive to tight/blurry face
  crops — small faces upscaled to 224 px score less reliably. Clear,
  front-facing, reasonably large faces work best.
- **Not our training.** If the examiner asks "did you train this model?",
  the honest answer is: "The demo uses a public pretrained classifier;
  our original contribution is the video-level pipeline, aggregation and
  application. Full self-training is implemented in `src/training/` +
  `notebooks/train_on_colab.ipynb` for the FaceForensics++ track."

## The self-trained track (unchanged)

Nothing about the original plan changed: `src/training/train.py` and
`notebooks/train_on_colab.ipynb` implement full EfficientNet-B0 training on
FaceForensics++/Celeb-DF via free Colab GPU. That remains the path to a
model trained by the student, with proper metrics for the FYP report.
