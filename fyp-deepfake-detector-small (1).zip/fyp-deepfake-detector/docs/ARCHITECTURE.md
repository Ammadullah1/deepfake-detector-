# Architecture — Deepfake Video Detector

## Pipeline (ASCII)

```
                        TRAINING (Colab GPU)
                        ====================
data/real, data/fake (*.mp4)
        │  src/data/extract_frames.py   (2 fps)
        ▼
data/frames/<label>/<video>/frame_*.jpg
        │  src/data/extract_faces.py    (MTCNN → largest face → 224×224)
        ▼
data/faces/<video>/face_*.jpg  +  data/manifest.csv
        │  src/training/dataset.py      (video-level train/val split)
        ▼
src/training/train.py  →  EfficientNet-B0 + Dropout(0.3) + Linear(1280→1)
        │  AdamW, cosine LR, AMP, early stopping, best-by-val-F1
        ▼
checkpoints/best.pt  +  metrics.json  +  confusion_matrix.png


                        INFERENCE (API / CLI)
                        =====================
                    POST /predict  (video ≤ 50 MB)
                                │
                                ▼
                    extract frames (2 fps, max 60)
                                │
                                ▼
                    MTCNN → largest face per frame → 224×224 crops
                                │   (frames with no face are skipped)
                                ▼
                    EfficientNet-B0 → sigmoid → per-frame fake p
                                │
                                ▼
                    aggregate: video_score = mean(top 50% scores)
                                │
                ┌───────────────┼────────────────┐
                ▼               ▼                ▼
            verdict        confidence     suspicious_segments
        FAKE / REAL    P(predicted)    runs with p > 0.7 (start–end s)
```

## Module responsibilities

| Module | Responsibility |
|---|---|
| `src/data/download_data.py` | Prints official dataset sources + verifies `data/real,data/fake` layout. Downloads nothing. |
| `src/data/extract_frames.py` | Video → JPEG frames at fixed fps. Single-video and batch modes. |
| `src/data/extract_faces.py` | MTCNN detection → largest-face 224×224 crops + `manifest.csv`. Shared by training prep and (via `detect_largest_face`) inference, so crops are identical in both. |
| `src/models/detector.py` | `DeepfakeDetector`: torchvision EfficientNet-B0 (ImageNet weights) with head `Dropout(0.3) → Linear(1280, 1)`. Forward returns logits. |
| `src/training/dataset.py` | Manifest → PyTorch `Dataset`; **video-level** train/val split (no frame leakage); train augmentations + ImageNet normalisation. |
| `src/training/train.py` | Config-driven loop: AdamW, cosine schedule, AMP on CUDA, early stopping, best-by-val-F1 checkpoint, `metrics.json`, confusion-matrix PNG. CPU-compatible. |
| `src/inference/aggregate.py` | Pure function: scores+timestamps → `{video_score, verdict, confidence, suspicious_segments}`. No ML deps — unit-testable. |
| `src/inference/predict.py` | `load_pipeline()` (weights+MTCNN once) and `predict_video()` (end-to-end, temp-dir frames). CLI wrapper. |
| `src/api/main.py` | FastAPI: `POST /predict`, `GET /health`, static demo UI. Model loads lazily on first prediction; 503 with a "train first" message when `checkpoints/best.pt` is absent. |
| `src/frontend/index.html` | Single-file demo UI (vanilla JS, no build): upload → progress → verdict card + confidence bar + per-frame canvas chart + suspicious segments. |

## API contract

`POST /predict` — `multipart/form-data` with field `file` (video, ≤ 50 MB).

Success `200`:
```json
{
  "video_score": 0.8734,
  "verdict": "FAKE",
  "confidence": 0.8734,
  "frames_analyzed": 42,
  "suspicious_segments": [
    {"start": 4.5, "end": 9.0, "max_score": 0.96}
  ],
  "frame_scores": [0.12, 0.91, ...],
  "frame_timestamps": [0.0, 0.5, ...]
}
```

- `verdict` is `"FAKE"` when `video_score >= 0.5`, else `"REAL"`;
  `"NO_FACE_DETECTED"` (with a human-readable `note`) when no face was found.
- `confidence` is the probability assigned to the predicted class.
- `suspicious_segments` lists contiguous runs of frames with score > 0.7.

Errors: `400` bad file type/empty, `413` over 50 MB, `422` unreadable video,
`503` no trained model yet (body explains how to train).

`GET /health` → `{"status": "ok", "model_loaded": bool, "device": "cuda"|"cpu"|null}`.

## Configuration

Everything lives in `configs/config.yaml` (paths, fps, thresholds, model and
training hyperparameters). CLI flags (`--epochs`, `--batch-size`, `--lr`,
`--manifest`, `--output-dir`) override single values without editing the file.
