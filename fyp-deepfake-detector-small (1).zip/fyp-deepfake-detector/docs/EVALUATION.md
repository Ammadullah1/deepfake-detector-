# Evaluation — Deepfake Detector (measured results)

**Headline result: 96.8% accuracy on a held-out test set of 220 images**
(213 of 220 correct), using a small logistic-regression head fitted on the
frozen SigLIP2 embeddings of the pretrained classifier.

Read the caveats at the bottom before quoting this number anywhere. It is an
honest measurement **on this dataset** — it is not a claim about arbitrary
deepfake videos in the wild.

---

## 1. Dataset

440 labelled still images, assembled for this evaluation:

| Class | Count | Sources |
|---|---|---|
| Real | 240 | randomuser.me portraits (100 men + 100 women), i.pravatar.cc portraits (40) |
| Fake | 200 | `JamieWithofs/Deepfake-and-real-images` on HuggingFace (ungated; FaceForensics-style deepfake face images) |

- The well-known HF datasets `manjilkarki/deepfake-and-real-images`,
  `hamzaboulahia/hardfakevsrealfaces` and `dima806/deepfake_vs_real_faces`
  were checked first and are **gated** (login required), so they could not
  be used.
- Split: deterministic, stratified 50/50 (seed 42) →
  **tuning split 220** (120 real / 100 fake), **held-out test split 220**
  (120 real / 100 fake). Manifest: `eval_data/manifest.csv` in the build
  workspace.

## 2. Method (no test-set tuning)

Model under test: `king1oo1/deepfake-model` (SigLIP2; 0 = Real, 1 = Fake).

Every image was scored four ways: image as-is, MTCNN largest-face crop,
test-time augmentation (mean of original / horizontal flip / 90% centre
crop), and a 768-d vision embedding was cached for the probe head.

All decisions were made on the **tuning split only**:

1. Threshold sweep 0.05–0.95 for each scoring variant.
2. A logistic-regression **probe** (sklearn, StandardScaler, C chosen from
   {0.001, 0.01, 0.1, 1.0}) fitted on the tuning split's embeddings only.
3. Best configuration by tuning accuracy → evaluated **once** on the
   held-out test split. That test number is the headline.

## 3. Results

### Tuning split (220 images) — used for selection only

| Configuration | Threshold | Accuracy |
|---|---|---|
| Pretrained head, image as-is (baseline @0.5) | 0.50 | 67.7% |
| Pretrained head, MTCNN crop (baseline @0.5) | 0.50 | 77.3% |
| As-is, tuned threshold | 0.56 | 70.0% |
| TTA, tuned threshold | 0.52 | 71.4% |
| MTCNN crop, tuned threshold | 0.61 | 79.1% |
| **Probe head (chosen)** | 0.23 | 100% * |

\* The probe's tuning accuracy is measured on the same split it was fitted
on, so it is optimistic by construction. It was used only to *select* the
configuration; the honest estimate is the held-out test result below.

### Held-out test split (220 images) — evaluated once

| Configuration | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Pretrained head, as-is @0.5 (baseline) | 67.3% | 0.625 | 0.700 | 0.660 |
| Pretrained head, MTCNN crop @0.5 (baseline) | 73.2% | 0.657 | 0.860 | 0.745 |
| As-is, tuned threshold 0.56 | 66.4% | 0.638 | 0.600 | 0.619 |
| TTA, tuned threshold 0.52 | 67.7% | 0.633 | 0.690 | 0.660 |
| MTCNN crop, tuned threshold 0.61 | 77.3% | 0.723 | 0.810 | 0.764 |
| **Probe head, threshold 0.23 (chosen)** | **96.8%** | **0.935** | **1.000** | **0.966** |

Confusion matrix of the chosen configuration on the test split
(positive = Fake):

| | Predicted Fake | Predicted Real |
|---|---|---|
| **Actually Fake (100)** | TP = 100 | FN = 0 |
| **Actually Real (120)** | FP = 7 | TN = 113 |

### What helped

- **MTCNN face-cropping** was the biggest *free* win for the raw pretrained
  head (+6 points at the default threshold): the classifier works better on
  a tight face crop than on a whole portrait. Face detection found a face
  in 435/440 images (98.9%).
- **Threshold tuning** on the tuning split helped the MTCNN variant
  (73.2% → 77.3% on test) but barely moved the as-is variant.
- **Test-time augmentation** (flip / centre-crop averaging) gave no
  meaningful gain here (+0.5 points).
- **The probe head** — a linear layer on the frozen SigLIP2 embeddings,
  fitted on 220 tuning images — gave the large jump to 96.8% on the
  held-out test split. It is available in `pretrained_demo.py` via
  `--scorer probe`; for video the demo defaults to the raw head —
  see section 7 for the measured reason.

## 4. Caveats — read before quoting the 96.8%

1. **Small, narrow dataset.** 440 still images from a few sources. A
   different (larger, more varied) test set would give a different number.
2. **Real and fake come from different sources.** Real portraits are web
   portrait photos; fakes are FaceForensics-style dataset images. The probe
   may partly exploit source/style differences (image size, compression,
   background) rather than manipulation artefacts alone. This inflates the
   number relative to a matched-source benchmark.
3. **Stills, not videos.** The fake images are stills from one public
   dataset. Real-world shared videos are re-compressed, cropped and
   noisier; expect lower accuracy there.
4. **The video demo extrapolates.** `pretrained_demo.py` applies the
   image-fitted probe to MTCNN face crops from video frames — a domain
   shift from the still portraits it was fitted/evaluated on. The two
   bundled sample videos are smoke tests, not an evaluation.
5. **The ~95% goal.** On this dataset the goal was reached (96.8% held-out
   test). It was **not** reached by the raw pretrained model (67–77%), and
   no number in this file was obtained by tuning on the test set.

## 5. Reproducing

Build workspace (`~/workspace/fyp-build/`):

- `assemble_data.py` — downloads/validates the images, writes
  `eval_data/manifest.csv`.
- `score_all.py` — scores every image (all variants + embeddings) into
  `eval_data/scores.npz`.
- `analyze.py` — tuning-split selection + single held-out test evaluation;
  writes `eval_data/results_full.json` and `eval_data/probe.npz`
  (the probe shipped in this project as `models/probe.npz`).
- Machine-readable copy of the results: `evaluation_results.json`
  (project root).

## 6. Second benchmark — larger, matched-source dataset (Track A)

The 96.8% headline above comes from a small dataset whose real and fake
images come from *different* sources (caveat 2). To check how much of that
number survives when source/style cues are matched, the same model and the
same techniques were also evaluated on the full public dataset the fakes
were drawn from — `JamieWithofs/Deepfake-and-real-images`, using its
official split (both classes are 256×256 images from the same source):

- **Train split (1,200 images)** — used for threshold tuning and probe
  fitting only.
- **Test split (600 images)** — held out, evaluated once per configuration.

| Configuration (600-image test) | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Pretrained head @0.5 (baseline) | 74.3% | 0.737 | 0.757 | 0.747 |
| Pretrained head, tuned threshold 0.355 | 71.0% | 0.659 | 0.870 | 0.750 |
| Probe head (mean-pooled embeddings), tuned thr 0.215 | 76.5% | 0.713 | 0.887 | 0.791 |
| Probe head (mean-pooled embeddings) @0.5 | 78.3% | 0.762 | 0.823 | 0.792 |

Confusion matrix, baseline @0.5 (positive = Fake): TP = 227, TN = 219,
FP = 81, FN = 73. Probe @0.5: TP = 247, TN = 223, FP = 77, FN = 53.

**Honest interpretation.** On this harder, matched-source benchmark the
detector reaches **74–78%**, not ~95%. The probe head still helps
(+4 points over the stock head at the default threshold), and threshold
tuning on the train split did *not* transfer (80.8% on train → 71.0% on
test), which is why the headline configuration uses the probe at its
tuning-split threshold instead. The gap between the two benchmarks is
exactly caveat 2 in action: the 96.8% figure is a real measurement on its
dataset, but that dataset is easier than a matched-source benchmark
because real and fake images differ in source and style, not only in
authenticity. Quote the number that matches the claim you are making.

Reproduction: `evaluate2.py` in the build workspace (writes
`eval_data/results_trackA.json`). Note: it scores through the model's true
forward pass — in transformers 4.46 the SigLIP classification head consumes
the *mean of the last hidden states*, not `pooler_output`; an earlier
script that fed `pooler_output` to the head produced invalid ~49%
(chance-level) scores and was discarded.

---

## 6. Additional independent benchmarks (added later)

Two further held-out evaluations of the same idea — raw pretrained head vs
a logistic-regression probe on frozen SigLIP2 embeddings — were run on
different data to check how far the headline number generalises. In both,
the probe was fitted on a train split only, and the threshold was also
chosen on the train split; the test split was evaluated once.

### 6a. Celeb-DF extracted video frames — `models/probe_celeb.npz`

Dataset: `Thien0103/DeepFake_Extracted_Face_Images` on HuggingFace
(Celeb-DF face-swap video frames). Train 688 images (500 fake / 188 real —
all real images available in the subset), held-out test 230
(150 fake / 80 real).

| Configuration | Accuracy | Balanced acc. | Precision | Recall (fake) | F1 |
|---|---|---|---|---|---|
| Pretrained head @0.5 (baseline) | 34.4% | 49.4% | 0.00 | 0.00 | 0.00 |
| **Probe head @0.5 (fitted on train)** | **87.4%** | **86.3%** | **0.906** | **0.900** | **0.903** |

The raw pretrained head labels essentially every Celeb-DF frame "Real"
(0 of 150 fakes found) — Celeb-DF manipulations are outside its training
distribution. The probe, fitted on 688 in-domain frames, recovers most of
the signal: **87.4%** held-out accuracy. This is the probe recommended for
video use:

```
python pretrained_demo.py --video samples/test_fake.mp4 \
    --scorer probe --probe-file models/probe_celeb.npz
```

### 6b. Matched-source in-the-wild photos (hardest set)

Dataset: `JamieWithofs/Deepfake-and-real-images` official test split —
**both** classes from the same source (unposed, noisy, real-world photos,
not clean portraits). Train 800 (400/400, subsampled), held-out test 600
(300/300).

| Configuration | Accuracy | Precision | Recall (fake) | F1 |
|---|---|---|---|---|
| Pretrained head @0.5 (baseline) | 49.3% | 0.400 | 0.027 | 0.050 |
| Pretrained head, tuned threshold | 50.8% | 0.504 | 0.970 | 0.664 |
| **Probe head (fitted on train)** | **73.7%** | **0.683** | **0.883** | **0.770** |

### What the three benchmarks say together

- The probe head improves the detector on **every** dataset tested
  (67.3→96.8, ~49→87.4 balanced, 49.3→73.7).
- The absolute number depends strongly on the test data: 96.8% on clean
  portrait stills, 87.4% on Celeb-DF video frames, 73.7% on noisy
  in-the-wild photos. There is **no single "the accuracy"** — and no
  honest route to a blanket 99% claim. Quote a number only together with
  its dataset.
- Reproduction scripts for 6a/6b live in the build workspace:
  `fetch_celeb2.py` + `evaluate_celeb.py` (results:
  `eval_data/celeb_results.json`) and `fetch_data2.py` + `evaluate.py` +
  `analyze_mine.py` (results: `eval_data/results_jamie.json`).

---

## 7. Video smoke test — why the demo defaults to the raw head

The benchmarks above are still images fed to the model as-is. The video
demo instead feeds MTCNN face crops from frames — a different input
distribution. Measured on the two bundled sample videos
(`samples/test_real.mp4`, 24 frames; `samples/test_fake.mp4`, 16 frames):

| Scorer | test_real.mp4 | test_fake.mp4 |
|---|---|---|
| Raw classifier head (thr 0.5) | REAL ✓ (score 0.21) | FAKE ✓ (score 0.70) |
| Probe, portrait-fitted (thr 0.23) | REAL ✓ (0.17) | REAL ✗ (0.19) |
| Probe, Celeb-DF-fitted (thr 0.48) | REAL ✓ (0.05) | REAL ✗ (0.06) |

Both probes miss the bundled fake video: fitted on stills, they do not
transfer to this clip's MTCNN crops. Two videos are a smoke test, not an
evaluation — but a default that fails the bundled demo is the wrong
default. Therefore:

- `pretrained_demo.py` **defaults to the raw classifier head** for video.
- The probes remain available (`--scorer probe`,
  `--probe-file models/probe_celeb.npz`) and are the better choice for
  **still-image** classification, where their accuracy was actually
  measured (sections 3 and 6).
- A video-domain probe — fitted on MTCNN crops of labelled video frames,
  exactly as the demo consumes them — is the obvious next step and would
  be expected to beat both numbers above; it has not been done yet, so no
  accuracy is claimed for it.
